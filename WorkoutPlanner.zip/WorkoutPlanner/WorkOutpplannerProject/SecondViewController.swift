//
//  SecondViewController.swift
//  WorkOutpplannerProject
//
//  Created by Student on 10/6/18.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var nameLBL: UILabel!
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var descView: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nameLBL.text = cardio[myIndex]
        descView.text = cardioDisc[myIndex]
        imageView.image = UIImage(named: "cardioImg")
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

