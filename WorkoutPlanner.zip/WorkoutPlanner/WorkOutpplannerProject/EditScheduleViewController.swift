//
//  EditScheduleViewController.swift
//  WorkOutpplannerProject
//
//  Created by student on 10/17/18.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit

class EditScheduleViewController: UIViewController {

    
    @IBOutlet weak var Day1TXT: UITextField!
    
    
    
    @IBOutlet weak var Day2TXT: UITextField!
    
    
    @IBOutlet weak var Day3TXT: UITextField!
    
    
    @IBOutlet weak var Day4TXT: UITextField!
    
   
    @IBOutlet weak var Day5TXT: UITextField!
    
    @IBOutlet weak var Day6TXT: UITextField!
    
    @IBAction func save(_ sender: Any) {
      
        if Day1TXT.text!.isEmpty == false{
            let s = Schedule.init(day: "day1", exercises: ["a123","b132","C344", Day1TXT.text!])

            detailSchedule.detail.schedules[0] = s
           
        }
        if Day2TXT.text!.isEmpty == false{
             let s = Schedule.init(day: "day2", exercises: ["qfr","wvr2","err", Day2TXT.text!])
           detailSchedule.detail.schedules[1] = s
        }
        if Day3TXT.text!.isEmpty == false{
            let s = Schedule.init(day: "day3", exercises: ["xrfwr","yvrvw","zvw", Day3TXT.text!])
            detailSchedule.detail.schedules[2] = s
        }
        if Day4TXT.text!.isEmpty == false{
            let s = Schedule.init(day: "day4", exercises: ["qvw","svwvw","zrfvr", Day4TXT.text!])
            detailSchedule.detail.schedules[3] = s
    
        }
        if Day5TXT.text!.isEmpty == false{
            let s = Schedule.init(day: "day5", exercises: ["qv2f","svrwv","cvwv", Day5TXT.text!])
            detailSchedule.detail.schedules[4] = s
        }
        if Day6TXT.text!.isEmpty == false{
            let s = Schedule.init(day: "day6", exercises: ["ovrw","p2vr","kvrww", Day6TXT.text!])
            detailSchedule.detail.schedules[5] = s
        }
        
    
        
    }
    

        
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
