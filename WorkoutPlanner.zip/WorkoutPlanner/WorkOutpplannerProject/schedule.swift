//
//  schedule.swift
//  WorkOutpplannerProject
//
//  Created by student on 10/18/18.
//  Copyright © 2018 Student. All rights reserved.
//

import Foundation

struct Schedule {
    var day : String
    var exercises : [String]
     static  var sch : Schedule!
}

struct detailSchedule {
    
    static var detail:detailSchedule = detailSchedule()
    
   private init(){}
    
    
    
  var schedules: [Schedule] = [
     
        Schedule(day : "day1" , exercises: ["a123","b132","C344"]),
        Schedule(day : "day2" , exercises: ["qfr","wvr2","err"]),
        Schedule(day : "day3" , exercises: ["xrfwr","yvrvw","zvw"]),
        Schedule(day : "day4" , exercises: ["qvw","svwvw","zrfvr"]),
        Schedule(day : "day5" , exercises: ["qv2f","svrwv","cvwv"]),
        Schedule(day : "day6" , exercises: ["ovrw","p2vr","kvrww"]),

    ]
    
    func numSchedule() -> Int {
        return schedules.count
    }
    
    func schedulenum(_ index : Int) -> Schedule {
        return schedules[index]
    }
    
    subscript (index:Int) -> Schedule {
        return schedules[index]
    }
    
    mutating func addNewSchedule (_ schedule:Schedule) {
        schedules.append(schedule)
    }

}
